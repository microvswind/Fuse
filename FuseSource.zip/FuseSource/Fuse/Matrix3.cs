using System.Runtime.InteropServices;

namespace Fuse;

[StructLayout(LayoutKind.Sequential, Size = 1)]
public struct Matrix3
{
}
